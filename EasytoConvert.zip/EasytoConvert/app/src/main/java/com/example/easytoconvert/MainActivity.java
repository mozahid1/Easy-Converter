package com.example.easytoconvert;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView t1,t2;
    EditText e1,e2;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1 = findViewById(R.id.textView4);
        t2 = findViewById(R.id.textView5);
        e1 = findViewById(R.id.editTextNumber2);
        e2 = findViewById(R.id.editTextNumber);
        b = findViewById(R.id.button2);

        b.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        double n = Double.parseDouble(e1.getText().toString());
        double cm = n*100;
        e2.setText(Double.toString(cm));

    }

}